def say_hi():
    print('Hi')